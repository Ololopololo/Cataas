import Foundation
import WANetwork

//class CatRoute: NetworkRouteProtocol {
//    
//    var query: (any WANetwork.Param)?
//    
//    var body: WANetwork.BodyData?
//    
//    var headers: [String : String?]
//    
//    func makeURLRequest(settings: any WANetwork.NetworkClientSettingsProtocol) -> URLRequest? {
//        <#code#>
//    }
//    
//    
//}
